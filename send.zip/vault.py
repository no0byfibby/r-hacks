import json
import os

from argon2.low_level import Type, hash_secret_raw
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .db import get_db


def _kek(password: str, salt: bytes) -> bytes:
    # Separate salt from the login hash, so the two are independent
    return hash_secret_raw(password.encode(), salt, time_cost=3,
                           memory_cost=64 * 1024, parallelism=4,
                           hash_len=32, type=Type.ID)


def create_vault(password: str):
    """Run once. Generates the DEK and stores it wrapped by the password."""
    dek, salt, nonce = AESGCM.generate_key(256), os.urandom(16), os.urandom(12)
    wrapped = AESGCM(_kek(password, salt)).encrypt(nonce, dek, b"vault-dek-v1")
    with get_db() as db:
        if db.execute("SELECT 1 FROM vault_meta").fetchone():
            raise RuntimeError("Vault already exists")
        db.execute("INSERT INTO vault_meta VALUES(1,?,?,?)", (salt, nonce, wrapped))


def rewrap(old_password: str, new_password: str):
    """Change the hardware password without re-encrypting any records.
    (Also update the admin login hash separately via setup_admin.)"""
    v = Vault()
    if not v.unseal(old_password):
        raise ValueError("Old password is wrong")
    salt, nonce = os.urandom(16), os.urandom(12)
    wrapped = AESGCM(_kek(new_password, salt)).encrypt(nonce, v._dek, b"vault-dek-v1")
    with get_db() as db:
        db.execute("UPDATE vault_meta SET salt=?, nonce=?, wrapped_dek=? WHERE id=1",
                   (salt, nonce, wrapped))


class Vault:
    def __init__(self):
        self._dek: bytes | None = None

    @property
    def sealed(self) -> bool:
        return self._dek is None

    def unseal(self, password: str) -> bool:
        with get_db() as db:
            m = db.execute("SELECT * FROM vault_meta WHERE id=1").fetchone()
        if not m:
            raise RuntimeError("No vault. Run: python -m app.setup_vault")
        try:
            self._dek = AESGCM(_kek(password, m["salt"])).decrypt(
                m["nonce"], m["wrapped_dek"], b"vault-dek-v1")
            return True
        except InvalidTag:
            return False

    def seal(self):
        self._dek = None

    def encrypt(self, obj: dict, aad: str) -> tuple[bytes, bytes]:
        nonce = os.urandom(12)  # fresh random nonce per record
        return nonce, AESGCM(self._dek).encrypt(
            nonce, json.dumps(obj).encode(), aad.encode())

    def decrypt(self, nonce: bytes, ct: bytes, aad: str) -> dict:
        # AAD binds the ciphertext to its row, so records can't be swapped around
        return json.loads(AESGCM(self._dek).decrypt(nonce, ct, aad.encode()))


vault = Vault()

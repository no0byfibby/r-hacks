"""One-time, after setup_admin: create the vault. Run: python -m app.setup_vault"""
import getpass

from .db import init_db
from .vault import create_vault

init_db()
pw = getpass.getpass("Hardware password (same as admin): ")
if getpass.getpass("Confirm: ") != pw:
    raise SystemExit("Mismatch.")
create_vault(pw)
print("Vault created. Back up your hardware password: there is NO recovery.")

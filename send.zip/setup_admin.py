"""One-time: create the admin account. Run: python -m app.setup_admin"""
import getpass

from .db import get_db, init_db
from .security import hash_secret

init_db()
email = input("Admin email: ").strip().lower()
pw = getpass.getpass("Hardware password (12+ chars): ")
if len(pw) < 12:
    raise SystemExit("Use at least 12 characters.")
if getpass.getpass("Confirm: ") != pw:
    raise SystemExit("Mismatch.")
with get_db() as db:
    db.execute("INSERT OR REPLACE INTO admins(email, hw_hash) VALUES(?,?)",
               (email, hash_secret(pw)))
print("Admin created.")
